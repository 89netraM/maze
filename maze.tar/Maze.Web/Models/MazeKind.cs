﻿namespace Maze.Web.Models;

public enum MazeKind
{
	Polar,
	HexHex,
}
